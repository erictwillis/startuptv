<!DOCTYPE html>

<?php 
include('db_connect.php');
$selData=mysql_fetch_array(mysql_query("select * from startuptv where id=1"));
$btnText=$selData['btnText'];
$currentHost=$selData['currentHost'];
$bio=$selData['bio'];
$topic=$selData['topic'];
$div1=$selData['div1'];
$div2=$selData['div2'];
$div3=$selData['div3'];
$div1Text=$selData['div1Text'];
$div2Text=$selData['div2Text'];
$div3Text=$selData['div3Text'];

?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Startup TV</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="./css/bootstrap-responsive.css" type="text/css">
    <link rel="stylesheet" href="./css/strip.css" type="text/css">
    <link rel="stylesheet" href="./css/strip-responsive.css" type="text/css">
   	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,600" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,700' rel='stylesheet' type='text/css'>
    
</head><body>

<section class="container">
    <nav class="navbar">
        <div class="navbar-inner">
            <div class="container">
                <a href="#" class="brand">Startup TV</a>
               
            </div>
        </div>
    </nav>
</section>

<section class="section-box shadow">
<div class="container"> 
    <div class="row" >
        <header class="highlight span12" >
            <h3><strong>Startup TV</strong> gets behind the scenes of the startup world, daily</h3>               
            <img id="feature-screenshot" src="./img/Image-1.jpg" alt="screenshot">           
            <p><a href="https://www.snapchat.com/add/startuptv" height="20px" width="73.09375px" class="big-btn"><?php echo $btnText; ?></a></p>
			
				<p >Current Host: <?php echo $currentHost; ?></p>  
				<p>Bio: <?php echo $bio; ?></p>  
				<p>Topics: <?php echo $topic; ?></p>
				
        </header>        
    </div>   
    </div>    
</section>

<section class="section-box shadow">
    <div class="container">     	
        <div class="row">        	
            <article class="span4 center-align">					
                <img src="<?php echo $div1; ?>" alt="responsive"/>                    
                <?php echo $div1Text; ?>
            </article>
            <article class="span4 center-align">
                <img src="<?php echo $div2; ?>" alt="twitter"/>
                <?php echo $div2Text; ?>
            </article>
            <article class="span4 center-align">

            	<img src="<?php echo $div3; ?>" alt="heartwork" />
                <h3>Crafted with love.</h3>
                 <?php echo $div3Text; ?>
            </article>                    	
   		</div>
    </div>   
</section> 



<footer class="container footer-box">   
    <hr class="shadow-line" />         
    
    <nav class="links">   
        <a href="#"><img src="img/twitter-icon.png" alt="twitter"></a>
        <a href="#"><img src="img/facebook-icon.png" alt="fb"></a>   
        <a href="#"><img src="img/googleplus-icon.png" alt="gplus"></a>      
    </nav>                 
             
</footer>
<script src="./js/jquery-1.8.0.min.js"></script>
<script src="./js/bootstrap.js"></script>

</body>
</html>

