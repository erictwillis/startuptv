<?php 
$db = "adminstartup";
$conn=@mysql_connect('localhost','root','');
if($conn) {
	mysql_select_db($db,$conn);
} else {
	echo "error";
}
?>
<?php 
/*
$hostname = "JoshiAgencies.db.9775950.hostedresource.com";
$username = "JoshiAgencies";
$dbname = "JoshiAgencies";
$password = "Tarunjoshi@25";

$conn=@mysql_connect($hostname,$username,$password);
if($conn) {
	mysql_select_db($dbname,$conn);
} else {
	echo "error";
}
*/ ?>
