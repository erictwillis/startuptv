<?php
$section1="";
$section2="";
$div1="";
$div2="";
$div3="";
?>